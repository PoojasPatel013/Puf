"""
PUF - Python Universal Framework for Model Version Control
"""

__version__ = "0.1.0"
